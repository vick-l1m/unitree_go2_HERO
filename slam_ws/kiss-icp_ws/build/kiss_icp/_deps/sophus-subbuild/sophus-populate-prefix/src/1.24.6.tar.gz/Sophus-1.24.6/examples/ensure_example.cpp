#include <iostream>

#include <sophus/common.hpp>

int main() { SOPHUS_ENSURE(false, "There is an error. Details: {}", 42); }
